console.log('Teste no console do JavaScript');
